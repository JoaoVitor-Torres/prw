<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu principal - IFSP</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <h1>Menu principal</h1>
    <div id="menu">
        <ul>
            <li><a href="cadastro_fluxocaixa.html"> Cadastrar o fluxo de caixa</a></li>
            <li><a href="listar_fluxocaixa.php"> Listar o fluxo de caixa</a></li>
            <li><a href="consulta_fluxocaixa.php"> Consultar o fluxo de caixa</a></li>
        </ul>
    </div>
</body>
</html>